var url_atual = window.location.href;
var url = url_atual.split("=");

if(url[0] == 'https://trincks.com.br/compra' || url[0] == 'https://trincks.com.br/endereco'  ){
    window.onload = function(){
    var campoCep = document.getElementsByName('postcode')[0];
    var att = document.createAttribute("onblur");
    att.value = "pesquisacep(this.value);";
    campoCep.setAttributeNode(att);
}
}

    function limpa_formulário_cep() {
            //Limpa valores do formulário de cep.
            document.getElementsByName('address1')[0].value=("");
            document.getElementsByName('address2')[0].value=("");
            document.getElementsByName('city')[0].value=("");
            document.getElementsByName('id_state')[0].value=("");
    }

    function meu_callback(conteudo) {
        if (!("erro" in conteudo)) {
            //Atualiza os campos com os valores.
            document.getElementsByName('address1')[0].value=(conteudo.logradouro);
            document.getElementsByName('address2')[0].value=(conteudo.bairro);
            document.getElementsByName('city')[0].value=(conteudo.localidade);
            console.log(conteudo.uf);
            (conteudo.uf == "AC" ? document.getElementsByName('id_state')[0].value='313': '');
            (conteudo.uf == "AL" ? document.getElementsByName('id_state')[0].value='314': '');
            (conteudo.uf == "AM" ? document.getElementsByName('id_state')[0].value='316': '');
            (conteudo.uf == "AP" ? document.getElementsByName('id_state')[0].value='315': '');
            (conteudo.uf == "BA" ? document.getElementsByName('id_state')[0].value='317': '');
            (conteudo.uf == "CE" ? document.getElementsByName('id_state')[0].value='318': '');
            (conteudo.uf == "DF" ? document.getElementsByName('id_state')[0].value='319': '');
            (conteudo.uf == "ES" ? document.getElementsByName('id_state')[0].value='320': '');
            (conteudo.uf == "GO" ? document.getElementsByName('id_state')[0].value='321': '');
            (conteudo.uf == "MA" ? document.getElementsByName('id_state')[0].value='322': '');
            (conteudo.uf == "MT" ? document.getElementsByName('id_state')[0].value='323': '');
            (conteudo.uf == "MG" ? document.getElementsByName('id_state')[0].value='325': '');
            (conteudo.uf == "MS" ? document.getElementsByName('id_state')[0].value='324': '');
            (conteudo.uf == "PA" ? document.getElementsByName('id_state')[0].value='326': '');
            (conteudo.uf == "PB" ? document.getElementsByName('id_state')[0].value='327': '');
            (conteudo.uf == "PR" ? document.getElementsByName('id_state')[0].value='328': '');
            (conteudo.uf == "PE" ? document.getElementsByName('id_state')[0].value='329': '');
            (conteudo.uf == "PI" ? document.getElementsByName('id_state')[0].value='330': '');
            (conteudo.uf == "RJ" ? document.getElementsByName('id_state')[0].value='331': '');
            (conteudo.uf == "RN" ? document.getElementsByName('id_state')[0].value='332': '');
            (conteudo.uf == "RS" ? document.getElementsByName('id_state')[0].value='333': '');
            (conteudo.uf == "RO" ? document.getElementsByName('id_state')[0].value='334': '');
            (conteudo.uf == "RR" ? document.getElementsByName('id_state')[0].value='335': '');
            (conteudo.uf == "SC" ? document.getElementsByName('id_state')[0].value='336': '');
            (conteudo.uf == "SP" ? document.getElementsByName('id_state')[0].value='337': '');
            (conteudo.uf == "SE" ? document.getElementsByName('id_state')[0].value='338': '');
            (conteudo.uf == "TO" ? document.getElementsByName('id_state')[0].value='339': '');


        } //end if.
        else {
            //CEP não Encontrado.
            limpa_formulário_cep();
            alert("CEP não encontrado.");
        }
    }
        
    function pesquisacep(valor) {

        //Nova variável "cep" somente com dígitos.
        var cep = valor.replace(/\D/g, '');

        //Verifica se campo cep possui valor informado.
        if (cep != "") {

            //Expressão regular para validar o CEP.
            var validacep = /^[0-9]{8}$/;

            //Valida o formato do CEP.
            if(validacep.test(cep)) {

                //Preenche os campos com "..." enquanto consulta webservice.
                document.getElementsByName('address1')[0].value="...";
                document.getElementsByName('address2')[0].value="...";
                document.getElementsByName('city')[0].value="...";
                document.getElementsByName('id_state')[0].value="...";
                // document.getElementById('rua').value="...";
                // document.getElementById('bairro').value="...";
                // document.getElementById('cidade').value="...";
                // document.getElementById('uf').value="...";
                // document.getElementById('ibge').value="...";

                //Cria um elemento javascript.
                var script = document.createElement('script');

                //Sincroniza com o callback.
                script.src = 'https://viacep.com.br/ws/'+ cep + '/json/?callback=meu_callback';

                //Insere script no documento e carrega o conteúdo.
                document.body.appendChild(script);
                alert("Insira o número.");

            } //end if.
            else {
                //cep é inválido.
                limpa_formulário_cep();
                alert("Formato de CEP inválido.");
            }
        } //end if.
        else {
            //cep sem valor, limpa formulário.
            limpa_formulário_cep();
        }
    };
