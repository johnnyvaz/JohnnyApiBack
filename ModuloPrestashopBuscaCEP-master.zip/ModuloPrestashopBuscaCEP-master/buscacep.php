<?php
if(!defined('_PS_VERSION_')){
	exit;
}
class buscacep extends Module{
	public function __construct(){
		$this->name='buscacep'; //nombre del módulo el mismo que la carpeta y la clase.
		$this->tab='Design'; // pestaña en la que se encuentra en el backoffice.
		$this->version="0.1.0";//version del modulo
		$this->author='Johnny Vaz';//autor del modulo
		$this->need_instance=0; //si no necesita cargar la clase en la página módulos,1 si fuese necesario.
		$this->ps_versions_compliancy=array('min' => '1.7.x.x', 'max' => _PS_VERSION_); //las versiones con las que el módulo es compatible.
		$this->bootstrap=true; //si usa bootstrap plantilla responsive.
		
		parent::__construct(); //llamada al constructor padre.
		$this->displayName='BuscaCEP'; // Nombre del módulo
		$this->limited_countries = array('BR'); //somente para brasil
		$this->description='Insere um javascript para busca de CEP.'; //Descripción del módulo
		$this->confirmUninstall=$this->l('Está seguro de desinstalar este modulo?'); //mensaje de alerta al desinstalar el módulo.
	}
	
	public function install(){
		
		include(dirname(__FILE__).'/sql/install.php');
		Configuration::updateValue('FLAGBRASIL_DELETE_NUMERO', 0);
		Configuration::updateValue('FLAGBRASIL_ATIVO', 1);
		
		return parent::install() &&
		$this->registerHook('top') &&
		$this->registerHook('header');
		//registrando en 2 hook()
	}
	
	public function uninstall() {
		$this->_clearCache('*');
		
		if((bool)Configuration::get('FLAGBRASIL_DELETE_DB') === true) {
			include(dirname(__FILE__).'/sql/uninstall.php');
		}
		
		return parent::uninstall() &&
		$this->unregisterHook('top') &&
		$this->unregisterHook('header');
	}
	public function hookHeader(){
		$this->context->controller->registerJavascript('modules-buscacep', 'modules/'.$this->name.'/views/js/buscacep.js');
		
	}
	
	public function getContent()
	{
		$output = '';
		
		$output .= $this->context->smarty->fetch($this->local_path.'views/templates/admin/configure.tpl');
		
		return $output;
	}
	
}
?>