<?php

$sql = array();

$sql[] = 'ALTER TABLE ' . _DB_PREFIX_. 'address ADD COLUMN numend VARCHAR(50) NULL DEFAULT NULL' ;

foreach ($sql as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}
