<?php

$sql = array();

$sql[] = 'ALTER TABLE '._DB_PREFIX_.'address DROP COLUMN `numend`';

foreach ($sql as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}
